/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Tienda;

import java.util.Scanner;
/**
 *
 * Martin Alexey Motilla Ayuso
 */
public class SimuladorTienda {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        final double IVA = 0.21;

        String nombreCliente;
        char codigoSeccion;
        int numeroArticulos;
        double precioUnitario;
        double subtotal;
        double totalConIva;
        boolean descuentoAplicable;
        int puntosAcumulados;

        System.out.print("Nombre del cliente: ");
        nombreCliente = scanner.nextLine();

        System.out.print("Codigo de seccion: ");
        codigoSeccion = scanner.nextLine().charAt(0);

        System.out.print("Numero de articulos: ");
        numeroArticulos = scanner.nextInt();

        System.out.print("Precio unitario: ");
        precioUnitario = scanner.nextDouble();

        subtotal = numeroArticulos * precioUnitario;

        totalConIva = subtotal + (subtotal * IVA);

        // Comprueba si tiene más de 5 unidades y el total supera 50 euros.
        descuentoAplicable = numeroArticulos > 5 && totalConIva > 50.0;

        // Convierte el total de double a int, eliminando los decimales.
        puntosAcumulados = (int) totalConIva;

        System.out.println();
        System.out.println("Cliente: " + nombreCliente
                + " | Seccion: " + codigoSeccion);

        System.out.printf("Subtotal: %.2f%n", subtotal);
        System.out.printf("Total con IVA: %.2f%n", totalConIva);

        System.out.println("Descuento aplicable: " + descuentoAplicable);
        System.out.println("Puntos acumulados: " + puntosAcumulados);

        scanner.close();
    }
}